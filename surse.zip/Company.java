package classes;

public class Company {
	private String companyName;
	private IPerson director;
	private float turnover;
	
	public Company(String name, IPerson dir, float turnover)
	{
		this.companyName=name;
		director=dir;
		this.turnover=turnover;
	}
	
	public boolean checkLegality()
	{
		if(director.getAge()<18)
			return false;
		if(turnover<0)
			return false;
		
		return true;		
	} 
}
