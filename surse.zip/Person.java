package classes;

public class Person implements IPerson {

	private String name;
	public String CNP;

	public Person() {
		this.name = "Nume initial";
		this.CNP = "1000000000001";
	}

	public Person(String name, String CNP) {
		this.name = name;
		this.CNP = CNP;
	}

	@Override
	public String getGender() {
		switch (CNP.charAt(0)) {
		case '1':
			return "M";
		case '2':
			return "F";
		}
		return "N/A";
	}

	@Override
	public int getAge() {
		int an=(1900 + Integer.parseInt("" + CNP.charAt(1) + CNP.charAt(2)));
		return an;
	}

	@Override
	public boolean checkCNP() {
		int s=0;	
		boolean rezultat = false;
		if(CNP.length()!=13)
			throw new IllegalArgumentException("CNP-ul nu are lungimea corecta");
		String number="279146358279";
		try{
			for(int i=0;i<12;i++){
				s+=Integer.parseInt(""+number.charAt(i))*Integer.parseInt(""+CNP.charAt(i));			
			}
			int cifra=s%11;
			if(cifra==10)
				cifra=1;
			rezultat=cifra==Integer.parseInt(""+CNP.charAt(12));
		}catch(Exception ert)
		{
			throw new IllegalArgumentException("CNP-ul contine caractere incorecte");
		}
		
		return rezultat;
	}

}
