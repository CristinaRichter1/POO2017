package classes;

import java.util.ArrayList;
import java.util.List;

public class Utils {

	public static int sum(int param1, int param2){
		return param1+param2;
	}
	
	public static double division(int param1, int param2){
		return param1/param2;
	}
	
	public static boolean isEven(int number){
		return number%2==0;
	}
	
	public List<Integer> n_even_numbers(int n) {
		List<Integer> lista = new ArrayList();
		for (int i = 0; i < n; i++)
			lista.add(i * 2);
		return lista;
	}
}
