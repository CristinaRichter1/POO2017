package classes;

public interface IPerson {
	public String getGender();
	
	public int getAge();
	
	public boolean checkCNP();
}
